/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import database.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author 
 */
public class UpdateStudentDetails1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session=request.getSession();
        String student_id1=(String)session.getAttribute("session_stu_id");
        String fname1=request.getParameter("fname1");
        String mname1=request.getParameter("mname1");
        String lname1=request.getParameter("lname1");
        String email1=(String)session.getAttribute("sesison_stu_email");
        String password1=request.getParameter("password1");
        String telephone1=request.getParameter("telephone1");
        String gender1=request.getParameter("gender1");
        String country1=request.getParameter("country1");
        String status1=request.getParameter("status1");
        String current_past1=request.getParameter("current_past1");
        String semyear1=request.getParameter("semyear1");
        String gpa1=request.getParameter("gpa1");
        
        try
        {
            Connection con=DbConnection.getConnect();
            PreparedStatement ps=con.prepareStatement("update student_details set fname='"+fname1+"', mname='"+mname1+"', lname='"+lname1+"', telephone='"+telephone1+"', gender='"+gender1+"', country='"+country1+"', status='"+status1+"', current_past='"+current_past1+"', semester='"+semyear1+"', gpa='"+gpa1+"' where email='"+email1+"'");
            int i1=ps.executeUpdate();
            
            PreparedStatement ps1=con.prepareStatement("update register set password='"+password1+"' where email='"+email1+"'");
            int i2=ps1.executeUpdate();
            
            if(i1>0 && i2>0)
            {
                response.sendRedirect("StudentSection.jsp");
            }
            else
            {
                response.sendRedirect("ErrorPage.jsp");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        }
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
