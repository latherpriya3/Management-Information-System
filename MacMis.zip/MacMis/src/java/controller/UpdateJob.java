/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import database.DbConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author 
 */
public class UpdateJob extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session=request.getSession();
        String jid=(String)session.getAttribute("session_jid");
        
        String job_group=request.getParameter("job_group1");
        String company=request.getParameter("company1");
        String internship_type=request.getParameter("internship_type1");
        String position=request.getParameter("position1");
        String description=request.getParameter("description1");
        String responsibilities=request.getParameter("responsibilities1");
        String requirements=request.getParameter("requirements1");
        String salary=request.getParameter("salary1");
        String status=request.getParameter("status1");
        String[] stu_emails = request.getParameterValues("checkbox1");
        if(stu_emails==null)
        {
            try
            {
                Connection con=DbConnection.getConnect();
                PreparedStatement ps=con.prepareStatement("update job_details set job_group='"+job_group+"', company='"+company+"', internship_type='"+internship_type+"', position='"+position+"', description='"+description+"', responsibilities='"+responsibilities+"', requirements='"+requirements+"', salary='"+salary+"', status='"+status+"', student_list='Available For All Students' where id='"+jid+"'");
                int i=ps.executeUpdate();
                if(i>0)
                {
                    response.sendRedirect("JobsSection.jsp");
                }
                
            }
            catch(Exception e)
            {
                out.println(".........."+e);
            }
        }
        else
        {
            List<String> list =  Arrays.asList(stu_emails);
        
            ArrayList<String> listWithQuotes = new ArrayList<String>();
            for(String element : list){
                listWithQuotes.add(element);
            }
            String finalString = StringUtils.join(listWithQuotes.iterator(),",");
            out.println(finalString);
            //out.println(stu_emails);

            try
            {
                Connection con=DbConnection.getConnect();
                PreparedStatement ps=con.prepareStatement("update job_details set job_group='"+job_group+"', company='"+company+"', internship_type='"+internship_type+"', position='"+position+"', description='"+description+"', responsibilities='"+responsibilities+"', requirements='"+requirements+"', salary='"+salary+"', status='"+status+"', student_list='"+finalString+"' where id='"+jid+"'");
                int i=ps.executeUpdate();
                if(i>0)
                {
                    response.sendRedirect("JobsSection.jsp");
                }
            }
            catch(Exception e)
            {
                out.println("----------"+e);
            }
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
