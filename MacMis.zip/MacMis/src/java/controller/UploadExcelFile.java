/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author 
 */
public class UploadExcelFile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        String UPLOAD_DIRECTORY = "C:\\Users\\Disha\\Documents\\NetBeansProjects\\MacMis\\build\\web\\upload\\";
        String filee = null;

        if (ServletFileUpload.isMultipartContent(request)) {
            try {
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

                for (FileItem item : multiparts) {
                    if (!item.isFormField()) {
                        if (item.getFieldName().equals("browse1")) {
                            filee = new File(item.getName()).getName();
                            item.write(new File(UPLOAD_DIRECTORY + filee));
                        }
                    }

                }
            } catch (Exception ex) {
                out.print("File Upload Failed due to " + ex);

            }

        } else {
            out.print("Sorry this Servlet only handles file upload request");

        }

        String new_file_path = UPLOAD_DIRECTORY + filee;

        FileInputStream inputStream = new FileInputStream(new File(new_file_path));

        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet firstSheet = workbook.getSheetAt(0);
        Iterator<Row> iterator = firstSheet.iterator();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql:///internship_db", "root", "");

            while (iterator.hasNext()) {
                Row nextRow = iterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();

                int k = 0;
                String  fname = "", mname = "",lname = "", gender = "", country = "", status = "", current_past = "", semester = "", gpa = "", email = "";

                double student_id=0, telephone=0;
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    //System.out.print(cell.getStringCellValue());

                    DataFormatter df = new DataFormatter();
                    String value = df.formatCellValue(cell);

                    if (k == 0)
                    {
                        out.println("11");
                        student_id = cell.getNumericCellValue();
                        k++;
                    }
                    else if (k == 1)
                    {
                        out.println("22");
                        fname = cell.getStringCellValue();
                        k++;
                    }
                    else if (k == 2)
                    {
                        mname = cell.getStringCellValue();
                        k++;
                    }
                    else if (k == 3)
                    {
                        lname = cell.getStringCellValue();
                        k++;
                    }
                    else if (k == 4)
                    {
                        email = cell.getStringCellValue();
                        k++;
                    }
                    else if (k == 5)
                    {
                        telephone = cell.getNumericCellValue();
                        k++;
                    }
                    else if (k == 6)
                    {
                        gender = cell.getStringCellValue();
                        k++;
                    }
                    else if (k == 7)
                    {
                        status = cell.getStringCellValue();
                        k=0;
                    }
                    System.out.print(" - ");
                }
                PreparedStatement ps = con.prepareStatement("insert into student_details(student_id, fname, mname, lname, telephone, gender, country, status, current_past, semester, gpa, email) values(?,?,?,?,?,?,?,?,?,?,?,?)");
                ps.setDouble(1, student_id);
                ps.setString(2, fname);
                ps.setString(3, mname);
                ps.setString(4, lname);
                ps.setDouble(5, telephone);
                ps.setString(6, gender);
                ps.setString(7, country);
                ps.setString(8, status);
                ps.setString(9, current_past);
                ps.setString(10, semester);
                ps.setString(11, gpa);
                ps.setString(12, email);
                ps.executeUpdate();
                System.out.println();
                
                
            }

            workbook.close();
            inputStream.close();
            response.sendRedirect("UploadExcelFile.jsp");
        } catch (Exception e) {
            out.println(e);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
